# 24x7-Foodies---Food-Ordering-Project-in-PHP

An online food ordering website that displays the menu of available food items along with their price and allows the user to place an order after choosing the items from the menu. Technologies used: HTML, CSS, Javascript, PHP, MySQL database.
